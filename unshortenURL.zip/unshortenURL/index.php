<!DOCTYPE html>
<html>
<center>      
 <form  action="" method="post">
<table>
<tr><td>Your Shorten URL</td><td><input name=url size=50></td>
<tr><td><input type="submit" value="Show Me The Truth" </td></tr>
</tr></table>
</form></center></html>
<?php
/*
***********************************************************
*             SourceCode Powered                          *
***********************************************************
*/
$url=$_POST['url'];
if (isset($url) AND !empty($url) AND 
filter_var($url, FILTER_VALIDATE_URL)):
//Encode URL
$urlEncode =urlencode($url);
//Decode URL
$urlDecode = htmlspecialchars(urldecode($urlEncode), ENT_QUOTES);
//Get Headers
$getHeaders = get_headers($urlDecode, 1);
if(is_array($getHeaders['Location'])):
$location = current($getHeaders['Location']);
else:
$location = $getHeaders['Location'];
endif;
//If Redirect 301, 302 or 303 : Display URL
if (strpos($getHeaders[0], '301') || strpos($getHeaders[0], '302') || strpos($getHeaders[0], '303') !== false):
echo '<center><p><a href="' . $location . '" target="_blank">' . $location . '</a>';
echo '</p></center>';
else:
echo '<p>This url is not redirected';
echo '</p>';
endif;
endif;
?>
    	  
       